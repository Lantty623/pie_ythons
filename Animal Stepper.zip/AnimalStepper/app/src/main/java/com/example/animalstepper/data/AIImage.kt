package com.example.animalstepper.data

import com.aallam.openai.api.BetaOpenAI
import com.aallam.openai.api.chat.ChatCompletionRequest
import com.aallam.openai.api.chat.ChatMessage
import com.aallam.openai.api.chat.ChatRole
import com.aallam.openai.api.image.ImageCreation
import com.aallam.openai.api.image.ImageSize
import com.aallam.openai.api.model.ModelId
import com.aallam.openai.client.OpenAI

class AIImage {
    private val p : String = "A photo of a "

    //Returns a fun fact about the given animal
    @OptIn(BetaOpenAI::class)
    suspend fun loadImageURL(animal: String) : String {
        try{
            val openAI = OpenAI("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")

            val images = openAI.imageURL(
                creation = ImageCreation(
                    prompt = p + animal,
                    n = 1,
                    size = ImageSize.is1024x1024
                )
            )

            return images[0].url
        }
        catch(e: Exception){
            return "https://static.vecteezy.com/system/resources/previews/005/337/799/original/icon-image-not-found-free-vector.jpg"
        }
    }
}