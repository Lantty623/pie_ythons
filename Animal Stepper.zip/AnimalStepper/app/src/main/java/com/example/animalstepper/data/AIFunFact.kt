package com.example.animalstepper.data

import com.aallam.openai.api.BetaOpenAI
import com.aallam.openai.api.chat.ChatCompletionRequest
import com.aallam.openai.api.chat.ChatMessage
import com.aallam.openai.api.chat.ChatRole
import com.aallam.openai.api.model.ModelId
import com.aallam.openai.client.OpenAI

class AIFunFact {
    private val q : String = "Tell me a one sentence fun fact about a "

    //Returns a fun fact about the given animal
    @OptIn(BetaOpenAI::class)
    suspend fun loadFact(animal: String) : String {
        val chatCompletionRequest : ChatCompletionRequest
        try{
            val openAI = OpenAI("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")
            val id = ModelId("gpt-3.5-turbo")
            chatCompletionRequest = ChatCompletionRequest(
                model = id,
                messages = listOf(
                    ChatMessage(
                        role = ChatRole.User,
                        content = q + animal
                    )
                )
            )
            return openAI.chatCompletion(chatCompletionRequest).choices[0].message?.content
                ?: "ERROR: Fun fact could not be generated. Please wait a few seconds before trying again!"
        }
        catch(e: Exception){
            return "ERROR: Fun fact could not be generated. " +
                    "Please wait a few seconds before selecting an animal and trying again!" +
                    "\nError code: $e"
        }
    }
}